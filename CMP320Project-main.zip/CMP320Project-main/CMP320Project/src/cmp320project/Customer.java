package cmp320project;



/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Yo200
 */
public class Customer {
    
int id,phone;
String name,password;

    Customer ( int C_id, String C_name,String C_Password){
        id = C_id;
        name = C_name;
        password = C_Password;
    }
    
}
